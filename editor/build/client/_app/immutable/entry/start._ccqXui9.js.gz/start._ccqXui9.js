import{a as t}from"../chunks/entry.COJlGQeR.js";export{t as start};
